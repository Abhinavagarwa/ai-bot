package ovh.tgrhavoc.aibot.nbt;

public enum CompressionType {
	NONE,
	GZIP,
	ZLIB
}
